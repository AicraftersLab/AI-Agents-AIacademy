# Agent AI : Tuteur 

Ce projet est une application Streamlit intégrant un agent intelligent éducatif basé sur l'API Gemini de Google. Il offre trois fonctionnalités principales à l'étudiant :

- 📚 Chatbot éducatif basé sur un cours PDF ou txt
- 📝 Générateur d'exercices selon le niveau de l'étudiant
- 📄 Générateur de résumé automatique du cours

# Installation
pip install -r requirements.txt

# Technologies utilisées
Streamlit  
Google Gemini API  
PyMuPDF (fitz)

# Exemple d’utilisation
L’étudiant charge un fichier PDF ou txt contenant le cours.  
Il choisit une des 3 options :
- Poser une question au chatbot  
- Générer des exercices adaptés à son niveau  
- Obtenir un résumé du cours

## Exécution
streamlit run tutor.py

Déposé par : Ilham Madihi
